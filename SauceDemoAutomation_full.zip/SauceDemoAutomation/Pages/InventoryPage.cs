using OpenQA.Selenium;
using System.Linq;

public class InventoryPage
{
    private readonly IWebDriver _driver;
    private readonly By productList = By.ClassName("inventory_item");

    public InventoryPage(IWebDriver driver)
    {
        _driver = driver;
    }

    public int GetProductCount()
    {
        return _driver.FindElements(productList).Count;
    }

    public void AddFirstProductToCart()
    {
        var addButtons = _driver.FindElements(By.ClassName("btn_inventory"));
        if (addButtons.Any())
        {
            addButtons.First().Click();
        }
    }
}
