using OpenQA.Selenium;

public class CartPage
{
    private readonly IWebDriver _driver;
    private readonly By cartItem = By.ClassName("cart_item");

    public CartPage(IWebDriver driver)
    {
        _driver = driver;
    }

    public int GetCartItemCount()
    {
        return _driver.FindElements(cartItem).Count;
    }
}
