using OpenQA.Selenium;
using Xunit;

public class LoginTests : IDisposable
{
    private IWebDriver _driver;
    private LoginPage _loginPage;

    public LoginTests()
    {
        _driver = WebDriverFactory.CreateWebDriver();
        _driver.Navigate().GoToUrl("https://www.saucedemo.com");
        _loginPage = new LoginPage(_driver);
    }

    [Fact]
    public void SuccessfulLogin()
    {
        _loginPage.Login("standard_user", "secret_sauce");
        Assert.Contains("/inventory.html", _driver.Url);
    }

    [Fact]
    public void FailedLoginInvalidPassword()
    {
        _loginPage.Login("standard_user", "wrong_password");
        Assert.Contains("Epic sadface", _driver.PageSource);
    }

    [Fact]
    public void FailedLoginInvalidUsername()
    {
        _loginPage.Login("invalid_user", "secret_sauce");
        Assert.Contains("Epic sadface", _driver.PageSource);
    }

    public void Dispose()
    {
        _driver.Quit();
    }
}
