using OpenQA.Selenium;
using Xunit;

public class InventoryTests : IDisposable
{
    private IWebDriver _driver;
    private InventoryPage _inventoryPage;
    private LoginPage _loginPage;

    public InventoryTests()
    {
        _driver = WebDriverFactory.CreateWebDriver();
        _driver.Navigate().GoToUrl("https://www.saucedemo.com");
        _loginPage = new LoginPage(_driver);
        _loginPage.Login("standard_user", "secret_sauce");
        _inventoryPage = new InventoryPage(_driver);
    }

    [Fact]
    public void ProductListIsDisplayed()
    {
        Assert.True(_inventoryPage.GetProductCount() > 0);
    }

    [Fact]
    public void AddProductToCart()
    {
        _inventoryPage.AddFirstProductToCart();
        Assert.Contains("Remove", _driver.PageSource);
    }

    public void Dispose()
    {
        _driver.Quit();
    }
}
