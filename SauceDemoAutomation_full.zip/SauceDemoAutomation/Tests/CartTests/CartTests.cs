using OpenQA.Selenium;
using Xunit;

public class CartTests : IDisposable
{
    private IWebDriver _driver;
    private CartPage _cartPage;
    private InventoryPage _inventoryPage;
    private LoginPage _loginPage;

    public CartTests()
    {
        _driver = WebDriverFactory.CreateWebDriver();
        _driver.Navigate().GoToUrl("https://www.saucedemo.com");
        _loginPage = new LoginPage(_driver);
        _loginPage.Login("standard_user", "secret_sauce");
        _inventoryPage = new InventoryPage(_driver);
        _inventoryPage.AddFirstProductToCart();
        _cartPage = new CartPage(_driver);
        _driver.Navigate().GoToUrl("https://www.saucedemo.com/cart.html");
    }

    [Fact]
    public void CartDisplaysAddedProduct()
    {
        Assert.True(_cartPage.GetCartItemCount() > 0);
    }

    public void Dispose()
    {
        _driver.Quit();
    }
}
