using Xunit;
using OpenQA.Selenium;

public class LoginTests : IDisposable
{
    private readonly IWebDriver driver;
    private readonly LoginPage loginPage;

    public LoginTests()
    {
        driver = WebDriverFactory.GetDriver();
        driver.Navigate().GoToUrl(ConfigurationManager.GetConfigValue("BaseUrl"));
        loginPage = new LoginPage(driver);
    }

    [Fact]
    public void LoginConCredencialesValidas()
    {
        loginPage.Login("standard_user", "secret_sauce");
        Assert.Contains("/inventory.html", driver.Url);
    }

    [Fact]
    public void LoginConCredencialesInvalidas()
    {
        loginPage.Login("invalid_user", "wrong_password");
        Assert.Contains("Epic sadface", driver.PageSource);
    }

    [Fact]
    public void LoginConUsuarioBloqueado()
    {
        loginPage.Login("locked_out_user", "secret_sauce");
        Assert.Contains("Epic sadface", driver.PageSource);
    }

    public void Dispose()
    {
        driver.Quit();
    }
}