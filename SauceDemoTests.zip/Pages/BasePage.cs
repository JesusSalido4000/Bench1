using OpenQA.Selenium;

public class BasePage
{
    protected IWebDriver Driver;

    public BasePage(IWebDriver driver)
    {
        Driver = driver;
    }

    protected void Click(By locator) => Driver.FindElement(locator).Click();
    protected void SendKeys(By locator, string text) => Driver.FindElement(locator).SendKeys(text);
    protected string GetText(By locator) => Driver.FindElement(locator).Text;
}