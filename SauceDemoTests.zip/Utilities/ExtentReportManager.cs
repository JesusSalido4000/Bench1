using AventStack.ExtentReports;
using AventStack.ExtentReports.Reporter;
using System;

public class ExtentReportManager
{
    private static ExtentReports _extent;
    private static ExtentTest _test;

    public static void StartReport()
    {
        var htmlReporter = new ExtentHtmlReporter("Reports/TestReport.html");
        _extent = new ExtentReports();
        _extent.AttachReporter(htmlReporter);
    }

    public static void LogTest(string testName, string status)
    {
        _test = _extent.CreateTest(testName);
        _test.Log(status == "PASS" ? Status.Pass : Status.Fail, testName);
    }

    public static void EndReport()
    {
        _extent.Flush();
    }
}