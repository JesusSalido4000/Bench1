using System.IO;
using Newtonsoft.Json.Linq;

public static class ConfigurationManager
{
    private static readonly JObject configData;

    static ConfigurationManager()
    {
        string json = File.ReadAllText("Config/appsettings.json");
        configData = JObject.Parse(json);
    }

    public static string GetConfigValue(string key)
    {
        return configData[key]?.ToString();
    }
}